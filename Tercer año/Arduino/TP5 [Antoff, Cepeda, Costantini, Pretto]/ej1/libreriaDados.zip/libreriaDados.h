#ifndef libreriaDados_h
#define libreriaDados_h
#include "Arduino.h"
const int DADO_GANADOR = 3;
const int tiempo = 1000;
const int maxInUse = 2;
const int e = 0;
const max7219_reg_noop        = 0x00;
const max7219_reg_digit0      = 0x01;
const max7219_reg_digit1      = 0x02;
const max7219_reg_digit2      = 0x03;
const max7219_reg_digit3      = 0x04;
const max7219_reg_digit4      = 0x05;
const max7219_reg_digit5      = 0x06;
const max7219_reg_digit6      = 0x07;
const max7219_reg_digit7      = 0x08;
const max7219_reg_decodeMode  = 0x09;
const max7219_reg_intensity   = 0x0a;
const max7219_reg_scanLimit   = 0x0b;
const max7219_reg_shutdown    = 0x0c;
const max7219_reg_displayTest = 0x0f;

class Dados
{
  public:
    Dados(int pinDataIn, int pinLoad, int pinClock);
    void jugar();
  private:
	void putbyte(byte data);
	void maxSingle(byte data);
	void maxAll(byte reg, byte col);
	void maxOne(byte maxNr, byte reg, byte col);
	int elegirRandom(int numeroDisplay);
	void espada(int numeroDisplay);
	void escudo(int numeroDisplay);
	void casco(int numeroDisplay);
	void mover(int numeroDisplay);
	void pierde_turno(int numeroDisplay);
	void power_up(int numeroDisplay);
};

#endif