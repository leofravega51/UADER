﻿--Crear la tabla departamento con los siguientes atributos
--codigo int, nombre varchar (20)
--codigo clave primaria

CREATE TABLE departamento(codigo int, nombre varchar(20), PRIMARY KEY (codigo))
