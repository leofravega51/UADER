--Insertar 4 departamentos que se denominarán: (‘PRODUCCION’,’COMPUTOS’,’VENTAS’,’DEPOSITO’)

﻿INSERT INTO departamento(codigo, nombre) 
VALUES (1,'PRODUCCION'), (2,'COMPUTOS'), (3,'VENTAS'), (4,'DEPOSITO')
