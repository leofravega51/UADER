--Eliminar el departamento ‘VENTAS’

﻿DELETE 
FROM departamento
WHERE(nombre='VENTAS')
