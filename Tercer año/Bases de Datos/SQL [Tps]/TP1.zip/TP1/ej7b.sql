﻿--Insertar datos en la table trabajapara

INSERT INTO trabajapara (dni, codigo, horas) VALUES (13334401, 1, 12), 
(25100000,2,18), (25321542,2,6), (27123456,2,8), 
(29332501,2,3), (33387695, 4, 2)