--De la tabla Empleado modificar la tupla (13334401,’RETAMAR’,’JOAQUIN’ ,’F’,35000) para
--modificar el valor del atributo género

﻿UPDATE empleado 
SET genero = 'M' 
WHERE( dni = 13334401) 
