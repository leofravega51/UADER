--Listar todos los empleados

﻿SELECT *
FROM empleado
