--Listar los empleados de genero masculino

﻿SELECT *
FROM empleado
WHERE (genero = 'M')
