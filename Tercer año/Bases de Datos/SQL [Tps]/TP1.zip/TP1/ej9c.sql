--Listar el mayor sueldo, el menor sueldo, el sueldo promedio de los empleados

﻿SELECT MAX(sueldo), MIN(sueldo), AVG(sueldo)
FROM empleado
