--Listar la cantidad de empleados cuyo sueldo supera 20000

﻿SELECT COUNT (*)
FROM empleado
WHERE (sueldo > 20000) 
